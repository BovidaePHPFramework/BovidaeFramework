<?php

namespace App\Models;
use Core\BovidaeORM;
use PDO;

/**
 * Example user model
 *
 * PHP version 7.0
 */
class Generator extends BovidaeORM
{

    
}
