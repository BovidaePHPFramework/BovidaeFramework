<?php

namespace App\Models;
use Core\BovidaeORM;
use PDO;


class Saleorders extends BovidaeORM
{
    protected static $table = 'sale_orders';
}