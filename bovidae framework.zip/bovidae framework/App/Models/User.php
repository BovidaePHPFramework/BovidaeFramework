<?php

namespace App\Models;
use Core\BovidaeORM;
use PDO;


class User extends BovidaeORM
{
   
}