<?php

namespace App\Models;
use Core\BovidaeORM;
use PDO;


class User_kainat extends BovidaeORM
{
    protected static $table = 'user';
}