<?php

namespace App\Models;
use Core\BovidaeORM;
use PDO;


class Saleorder extends BovidaeORM
{
    protected static $table = 'orders';
}