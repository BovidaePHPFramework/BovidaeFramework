<?php

namespace App\Controllers;
use Core\View;
use App\Models\User;
use App\Models\City;
use App\Models\Generator;
use Config\Database;

class GeneratorController extends \Core\Controller

{
	public function indexAction()
	{
		//$user = User::find(1);
		//$user->name = 'asma malik';
		//$user->save();
		//$city = new City;
		//$city->city_name = "Rawalpindi";
		//$city->country = "Pakistan";
		//$city->save();

		View::renderTemplate('generator/home.html');
	}

	public function createModelAction()
	{

		if (!empty($_POST))
		{
			$model_name = ucfirst(strtolower($_POST['model_name']));
			$table_name = "";

			if (isset($_POST['check_explicit']))
			{
				$model_name = ucfirst(strtolower($_POST['e_model_name']));
				$table_name = strtolower($_POST['e_table_name']);
			}

			$str = file_get_contents("../generator/sample_model.php");
			$str = str_replace("{ MODEL_NAME }", $model_name, $str);
			
			if (isset($_POST['check_explicit']))
				$str = str_replace("{ TABLE_NAME }", "protected static \$table = '".$table_name."';", $str);
			else
				$str = str_replace("{ TABLE_NAME }", "", $str);
			

			$modelFile = fopen("../App/Models/".$model_name.".php", "w");

			fwrite($modelFile, $str);
			fclose($modelFile);
			
		}

		$tables = Generator::sql("SELECT TABLE_NAME AS _table FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '".Database::DB_NAME."'");
		
		View::renderTemplate('generator/create_model.html',  array('tables' => $tables));
	}
	public function createControllerAction()
	{
		if (!empty($_POST))
		{

			$controllerFile = fopen("../app/controllers/".$_POST['newcontroller'].".php", "w");
			$sampleCode = "<?php\n\n";
			$sampleCode .= "namespace App\Controllers;\n\n";
			$sampleCode .= "class {$_POST['newcontroller']} extends \Core\Controller\n";
			$sampleCode .= "{\n";
			$sampleCode .= "\tpublic function indexAction()\n";
			$sampleCode .= "\t{\n\n";
			$sampleCode .= "\t}\n";
			$sampleCode .= "}";
			$sampleCode = ltrim($sampleCode);

		fwrite($controllerFile, $sampleCode);
		fclose($controllerFile);
		}

		$dir    = '../app/models';
        $list = array_diff(scandir($dir), array('..', '.'));
		View::renderTemplate('generator/create_controller.html', array('models'=>$list));
		
	}
	public function createViewAction()
	{
		if (!empty($_POST))
		{
			$viewPath = "../app/views/".trim($_POST['view_path']);
			$viewPath = rtrim($viewPath,"/");
			mkdir($viewPath, 0, true);

			$viewName = fopen($viewPath."/".$_POST['view_name'],"w");
			fwrite($viewName, "");
			fclose($viewName);	
		}
		View::renderTemplate('generator/create_view.html');
	}
	public function allModelsAction()
	{
		$dir    = '../app/models';
        $list = array_diff(scandir($dir), array('..', '.'));
		View::renderTemplate('generator/list_models.html', array('model_list'=>$list));

	}
	public function allControllersAction()
	{
		$dir    = '../app/controllers';
        $list = array_diff(scandir($dir), array('..', '.'));
		View::renderTemplate('generator/list_controllers.html', array('controller_list'=>$list));
	}
	public function clearCacheAction()
	{
		View::renderTemplate('generator/clear_cache.html');
	}
	public function cCacheAction()
	{
		View::renderTemplate('generator/home.html');
	}

}