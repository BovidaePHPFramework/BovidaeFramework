<?php

namespace App\Controllers;
use Core\View;
use App\Models\User;
use App\Models\Generator;

class GeneratorController extends \Core\Controller

{
	public function indexAction()
	{
		$user = User::where("id","LIKE","%1%")
					 ->andWhereIn("id", "1,2,3")
					 ->andWhere("id",'>',"1")
					 ->orWhere("id","<","34")
					 ->orderBy("id","DESC")
					 ->orderBy("user_name", "DESC")
					 ->orderBy("address", "ASC")
					 ->fetch();

		View::renderTemplate('generator/home.html');
	}

	public function createModelAction()
	{
		if (!empty($_POST))
		{
			$model_name = ucfirst(strtolower($_POST['model_name']));
			$table_name = "";

			if (isset($_POST['check_explicit']))
			{
				$model_name = ucfirst(strtolower($_POST['e_model_name']));
				$table_name = strtolower($_POST['e_table_name']);
			}

			$str = file_get_contents("../generator/sample_model.php");
			$str = str_replace("{ MODEL_NAME }", $model_name, $str);
			
			if (isset($_POST['check_explicit']))
				$str = str_replace("{ TABLE_NAME }", "protected static \$table = '".$table_name."';", $str);
			else
				$str = str_replace("{ TABLE_NAME }", "", $str);
			

			$modelFile = fopen("../App/Models/".$model_name.".php", "w");

			fwrite($modelFile, $str);
			fclose($modelFile);
			
		}
		$tables = Generator::sql("SELECT TABLE_NAME AS _table FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '".Generator::getDatabaseName()."'");
		
		View::renderTemplate('generator/create_model.html',  array('tables' => $tables));
	}
	public function createControllerAction()
	{
		
		if (!empty($_POST))
		{
			$controllerFile = fopen("../app/controllers/".$_POST['newcontroller'].".php", "w");
			$sampleCode = "<?php\n\n";
			$sampleCode .= "namespace App\Controllers;\n\n";
			$sampleCode .= "class {$_POST['newcontroller']} extends \Core\Controller\n";
			$sampleCode .= "{\n";
			$sampleCode .= "\tpublic function indexAction()\n";
			$sampleCode .= "\t{\n\n";
			$sampleCode .= "\t}\n";
			$sampleCode .= "}";
			$sampleCode = ltrim($sampleCode);

		fwrite($controllerFile, $sampleCode);
		fclose($controllerFile);
		}
		
		View::renderTemplate('generator/create_controller.html');
		
	}
	public function createViewAction()
	{
		View::renderTemplate('generator/create_view.html');
	}
	public function allModelsAction()
	{
		View::renderTemplate('generator/all_models.html');
	}
	public function allControllersAction()
	{
		View::renderTemplate('generator/all_controllers.html');
	}
	public function clearCacheAction()
	{
		View::renderTemplate('generator/clear_cache.html');
	}

}