<?php

namespace App\Models;
use Core\BovidaeORM;
use PDO;


class { MODEL_NAME } extends BovidaeORM
{
    { TABLE_NAME }
}