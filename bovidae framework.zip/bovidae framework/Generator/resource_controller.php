<?php

namespace App\Controllers;
use \Core\Controller;
use Core\View;

{ MODEL_NAMESPACE }


class { CONTROLLER_NAME } extends Controller
{

	public function index()
	{

	}

	public function create()
	{

	}

	public function store()
	{

	}

	public function show()
	{

	}

	public function edit()
	{

	}

	public function update()
	{

	}

	public function destroy()
	{
		
	}
}