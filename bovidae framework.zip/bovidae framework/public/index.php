<?php

/**
 * Front controller
 *
 * PHP version 7.0
 */

/**
 * Composer
 */
require dirname(__DIR__) . '/vendor/autoload.php';

/**
 * Error and Exception handling
 */
#report all errors
error_reporting(E_ALL); 
set_error_handler('Core\Error::errorHandler');
set_exception_handler('Core\Error::exceptionHandler');



use Core\Route;

require dirname(__DIR__).'/routes/web.php';

/**
 * Routing
 */
Route::dispatch($_SERVER['QUERY_STRING']);
