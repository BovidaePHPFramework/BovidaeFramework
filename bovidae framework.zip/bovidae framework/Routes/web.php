<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Core\Route;

Route::add('', 'GeneratorController@index');
Route::add('generator', 'GeneratorController@index');
Route::add('generator/create_model', 'GeneratorController@createModel');
Route::add('generator/create_controller', 'GeneratorController@createController');
Route::add('generator/create_view', 'GeneratorController@createView');
Route::add('generator/clear_cache', 'GeneratorController@clearCache');
Route::add('generator/list_models', 'GeneratorController@allModels');
Route::add('generator/list_controllers', 'GeneratorController@allControllers');
Route::add('generator/home', 'GeneratorController@cCache');
//$route->add('{controller}/{action}');
//$route->add('{controller}/{action}');
